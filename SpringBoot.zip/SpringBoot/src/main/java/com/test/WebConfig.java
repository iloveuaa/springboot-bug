package com.test;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		// 自定义静态资源路径
		registry.addResourceHandler("/js/**", "/css/**", "/images/**")
				.addResourceLocations("classpath:static");
//                .setCacheControl(CacheControl.maxAge(365, TimeUnit.DAYS))
		;
//		WebMvcConfigurer.super.addResourceHandlers(registry);
	}
}
